# pyright: reportMissingImports = false, reportUndefinedVariable = false
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# File Name:  	CommInterfaceParamMP_pp.py
# Class Name:  	CommInterfaceParam_pp.py
# Description:	
# Company:	    dieEntwickler Elektronik GmbH
# Author:	    Manfred PEIRLEITNER
# Date:		    2022/05/18
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

from ..libraries_common import *;

# ----------------------------------------------------------------------------------------------------
# brief:        CommParams_pp
# details:      
# param[in]:    ---
# param[out]:   ---
# ----------------------------------------------------------------------------------------------------
class CommParams_pp( object ):
    pass;