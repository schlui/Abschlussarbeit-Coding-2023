# pyright: reportMissingImports = false, reportUndefinedVariable = false

from ...PythonScripts.ChamberTestrun import *;

climateChamber.getChamberTemperaturePV( );